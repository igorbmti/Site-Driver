// RECEITA MENSAL

const meses = receitaMensal.map(item =>
    `${item.Mes}/${item.Ano}`
);

const valoresReceita = receitaMensal.map(item =>
    parseFloat(item.Receita)
);

new Chart(
    document.getElementById("receitaMensal"),
    {
        type: "line",

        data: {
            labels: meses,

            datasets: [{
                label: "Receita",

                data: valoresReceita,

                borderColor: "#ffbf00",

                backgroundColor: "rgba(255,191,0,.15)",

                fill: true,

                tension: .4
            }]
        },

        options: {
            responsive: true,

            plugins: {
                legend: {
                    labels: {
                        color: "#fff"
                    }
                }
            },

            scales: {
                x: {
                    ticks: {
                        color: "#fff"
                    }
                },

                y: {
                    ticks: {
                        color: "#fff"
                    }
                }
            }
        }
    }
);

// RECEITA POR PLATAFORMA

new Chart(
    document.getElementById("plataformaChart"),
    {
        type: "doughnut",

        data: {

            labels: plataforma.map(p => p.NomePlataforma),

            datasets: [{
                data: plataforma.map(p => p.Receita),

                backgroundColor: [
                    "#00e676",
                    "#2196f3",
                    "#ff9800"
                ]
            }]
        }
    }
);

// FORMAS DE PAGAMENTO

new Chart(
    document.getElementById("pagamentoChart"),
    {
        type: "doughnut",

        data: {

            labels: pagamentos.map(p =>
                p.Tipo_Pagamento
            ),

            datasets: [{
                data: pagamentos.map(p =>
                    p.Receita
                ),

                backgroundColor: [
                    "#00e676",
                    "#2196f3",
                    "#ff9800"
                ]
            }]
        }
    }
);

// CUSTOS

new Chart(
    document.getElementById("custosChart"),
    {
        type: "bar",

        data: {

            labels: custos.map(c =>
                c.Descricao
            ),

            datasets: [{
                label: "Custos",

                data: custos.map(c =>
                    c.Total
                ),

                backgroundColor: "#ff4d4d"
            }]
        },

        options: {

            indexAxis: "y",

            plugins: {
                legend: {
                    labels: {
                        color: "#fff"
                    }
                }
            },

            scales: {

                x: {
                    ticks: {
                        color: "#fff"
                    }
                },

                y: {
                    ticks: {
                        color: "#fff"
                    }
                }
            }
        }
    }
);