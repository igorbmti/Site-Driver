<?php

require_once 'includes/conexao.php';
require_once 'includes/dashboard_dados.php';

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Focus Driver Dashboard</title>

<link rel="stylesheet" href="assets/style.css">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

<body>

<div class="container">

    <aside class="sidebar">

        <div class="logo">
            <h2>FOCUS</h2>
            <span>DRIVER</span>
        </div>

        <nav>

            <a href="#" class="active">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>

            <a href="#">
                <i class="fas fa-car"></i>
                Corridas
            </a>

            <a href="#">
                <i class="fas fa-users"></i>
                Motoristas
            </a>

            <a href="#">
                <i class="fas fa-car-side"></i>
                Veículos
            </a>

            <a href="#">
                <i class="fas fa-wallet"></i>
                Pagamentos
            </a>

            <a href="#">
                <i class="fas fa-money-bill"></i>
                Custos
            </a>

        </nav>

    </aside>

    <main class="content">

        <header class="topbar">

            <div>
                <h1>Dashboard Operacional</h1>
                <p>Visão geral da operação</p>
            </div>

        </header>

        <section class="kpis">

            <div class="card green">
                <h4>Receita Total</h4>
                <h2>
                    R$
                    <?= number_format($kpi['ReceitaTotal'],2,',','.'); ?>
                </h2>
            </div>

            <div class="card blue">
                <h4>Lucro Líquido</h4>
                <h2>
                    R$
                    <?= number_format($lucro['Lu'],2,',','.'); ?>
                </h2>
            </div>

            <div class="card purple">
                <h4>Total Corridas</h4>
                <h2><?= $kpi['TotalCorridas']; ?></h2>
            </div>

            <div class="card orange">
                <h4>Ticket Médio</h4>
                <h2>
                    R$
                    <?= number_format($kpi['TicketMedio'],2,',','.'); ?>
                </h2>
            </div>

            <div class="card cyan">
                <h4>KM Rodados</h4>
                <h2>
                    <?= number_format($kpi['TotalKM'],0,',','.'); ?>
                </h2>
            </div>

        </section>

        <section class="charts-top">

            <div class="panel large">
                <h3>Receita Mensal</h3>
                <canvas id="receitaMensal"></canvas>
            </div>

            <div class="panel">
                <h3>Receita por Plataforma</h3>
                <canvas id="plataformaChart"></canvas>
            </div>

            <div class="panel">
                <h3>Forma de Pagamento</h3>
                <canvas id="pagamentoChart"></canvas>
            </div>

        </section>

        <section class="charts-bottom">

            <div class="panel">
                <h3>Custos por Categoria</h3>
                <canvas id="custosChart"></canvas>
            </div>

        </section>

        <section class="tables">

            <div class="panel">

                <h3>Top Motoristas</h3>

                <table>

                    <tr>
                        <th>Motorista</th>
                        <th>Corridas</th>
                        <th>Receita</th>
                    </tr>

<?php foreach($motoristas as $m): ?>

<tr>

<td><?= $m['Nome'] ?></td>

<td><?= $m['Corridas'] ?></td>

<td>
R$ <?= number_format($m['Receita'],2,',','.') ?>
</td>

</tr>

<?php endforeach; ?>
                </table>

            </div>

            <div class="panel">

                <h3>Top Veículos</h3>

                <table>

                    <tr>
                        <th>Veículo</th>
                        <th>Corridas</th>
                        <th>Receita</th>
                    </tr>

<?php foreach($veiculos as $v): ?>

<tr>

<td>
<?= $v['Marca'] ?>
<?= $v['Modelo'] ?>
</td>

<td>
<?= $v['Corridas'] ?>
</td>

<td>
R$ <?= number_format($v['Receita'],2,',','.') ?>
</td>

</tr>

<?php endforeach; ?>
                </table>

            </div>

        </section>

    </main>

</div>

<script>

const receitaMensal = <?= json_encode($mensal); ?>;
const plataforma = <?= json_encode($plataformas); ?>;
const pagamentos = <?= json_encode($pagamentos); ?>;
const custos = <?= json_encode($custos); ?>;

</script>

<script src="assets/dashboard.js"></script>

</body>
</html>