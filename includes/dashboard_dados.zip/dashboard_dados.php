<?php

require_once 'conexao.php';

/* KPI GERAL */
$sqlKPI = "SELECT TOP 1 * FROM vw_KPI_Geral";
$stmtKPI = $pdo->query($sqlKPI);
$kpi = $stmtKPI->fetch(PDO::FETCH_ASSOC);

/* LUCRO */
$sqlLucro = "SELECT TOP 1 * FROM vw_LucroGeral";
$stmtLucro = $pdo->query($sqlLucro);
$lucro = $stmtLucro->fetch(PDO::FETCH_ASSOC);

/* RECEITA PLATAFORMA */
$sqlPlat = "SELECT * FROM vw_ReceitaPlataforma";
$stmtPlat = $pdo->query($sqlPlat);
$plataformas = $stmtPlat->fetchAll(PDO::FETCH_ASSOC);

/* RECEITA MENSAL */
$sqlMensal = "SELECT * FROM vw_ReceitaMensal ORDER BY Ano, Mes";
$stmtMensal = $pdo->query($sqlMensal);
$mensal = $stmtMensal->fetchAll(PDO::FETCH_ASSOC);

/* TOP MOTORISTAS */
$sqlMotoristas = "SELECT TOP 5 * FROM vw_TopMotoristas";
$stmtMotoristas = $pdo->query($sqlMotoristas);
$motoristas = $stmtMotoristas->fetchAll(PDO::FETCH_ASSOC);

/* TOP VEICULOS */
$sqlVeiculos = "SELECT TOP 5 * FROM vw_TopVeiculos";
$stmtVeiculos = $pdo->query($sqlVeiculos);
$veiculos = $stmtVeiculos->fetchAll(PDO::FETCH_ASSOC);

/* FORMAS DE PAGAMENTO */
$sqlPagamento = "SELECT * FROM vw_FormaPagamento";
$stmtPagamento = $pdo->query($sqlPagamento);
$pagamentos = $stmtPagamento->fetchAll(PDO::FETCH_ASSOC);

/* CUSTOS */
$sqlCustos = "SELECT * FROM vw_CustosCategoria";
$stmtCustos = $pdo->query($sqlCustos);
$custos = $stmtCustos->fetchAll(PDO::FETCH_ASSOC);