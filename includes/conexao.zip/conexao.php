<?php

$server = "localhost";
$database = "Site Driver";

try {

    $pdo = new PDO(
        "sqlsrv:Server=$server;Database=$database",
        "",
        ""
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch(PDOException $e){

    die("Erro de conexão: " . $e->getMessage());

}